function DCM = ECI2ECEF_DCM(time)

    time2longitude = siderealTime(juliandate(datetime(time)));
    time2longitude = time2longitude*pi/180;
    
    R_LT  = [cos(time2longitude) -sin(time2longitude)  0.0; ...
             sin(time2longitude)  cos(time2longitude)  0.0; ...
             0.0             0.0             1.0];

    DCM = R_LT';
    % R_LT  Rotation Matrix from ECEF to ECI
    % R_LT' Coordinate Transform Matrix from ECI to ECEF
end