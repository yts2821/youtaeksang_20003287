close
clear
clc
load nav.mat
GPS_a = (nav.GPS.a) / 10^3;                                              
GPS_e = nav.GPS.e;                                                  
GPS_p = GPS_a * (1- GPS_e^2);                                       
GPS_i = nav.GPS.i*180/pi;                                         
GPS_arg = nav.GPS.omega*180/pi;                                    
GPS_RAAN = nav.GPS.OMEGA*180/pi;         
GPS_M0 = nav.GPS.M0;                                                       
GPS_t = zeros(1440,6);
for i=0:1:1440
    nu(i+1) = true_anomaly(GPS_a, GPS_e, [0 0 0 0 i 0], nav.GPS.toc, GPS_M0);
    GPS_t(i+1,:) = nav.GPS.toc+[0 0 0 0 i 0];
end
GPS_ENU=[0 0 0];
%ground station
lat=37;             
lon=127;            
h=1;                
el_mask=10;         

GPS_rangelnPQW = zeros(3,1440);
GPS_velocitylnPQW = zeros(3,1440);
%24hour in min
for t=1:1:1441
    %PQW range & velocity
    GPS_rangelnPQW(:,t) = solveRangelnPerifocalFrame(GPS_a, GPS_e, nu(t)*180/pi);
    GPS_velocitylnPQW(:,t) = solveVelocitylnPerifocalFrame(GPS_a, GPS_e, nu(t)*180/pi);
end

    %PQW -> ECI
    GPS_ECI = PQW2ECI(GPS_arg, GPS_i, GPS_RAAN);
    GPS_rangelnECI=GPS_ECI*GPS_rangelnPQW;
    GPS_velocitylnECI=GPS_ECI*GPS_velocitylnPQW;
    
    %ECI -> ECEF
    GPS_rangelnECEF = zeros(3,1440);
    GPS_velocitylnECEF = zeros(3,1440);
    for t=1:1:1441
        DCM=ECI2ECEF_DCM(GPS_t(t,:)); 
        GPS_rangelnECEF(:,t)=DCM*GPS_rangelnECI(:,t); 
        GPS_velocitylnECEF(:,t)=DCM*GPS_velocitylnECI(:,t);
    end
    
    %ECEF-> geodetic
    wgs84 = wgs84Ellipsoid('kilometer');
    for t=1:1:1441
        [lat(t), lon(t), h(t)]= ecef2geodetic(wgs84, GPS_rangelnECEF(1,t),GPS_rangelnECEF(2,t),GPS_rangelnECEF(3,t));

    end
% ground track
figure(1)
geoplot(lat, lon,'y.')
geolimits([-90 90],[-180 180]) 
legend('GPS')

figure(2);
plot3(GPS_rangelnECI(1,:),GPS_rangelnECI(2,:),GPS_rangelnECI(3,:))