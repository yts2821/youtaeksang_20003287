close
clear
clc
load nav.mat
BDS_a = (nav.BDS.a) / 10^3;                                              
BDS_e = nav.BDS.e;                                                  
BDS_p = BDS_a * (1- BDS_e^2);                                       
BDS_i = nav.BDS.i*180/pi;                                         
BDS_arg = nav.BDS.omega*180/pi;                                    
BDS_RAAN = nav.BDS.OMEGA*180/pi;         
BDS_M0 = nav.BDS.M0;                                                       
BDS_t = zeros(1440,6);
for i=0:1:1440
    nu(i+1) = true_anomaly(BDS_a, BDS_e, [0 0 0 0 i 0], nav.BDS.toc, BDS_M0);
    BDS_t(i+1,:) = nav.BDS.toc+[0 0 0 0 i 0];
end
BDS_ENU=[0 0 0];
%ground station
lat=37;             
lon=127;            
h=1;                
el_mask=10;         

BDS_rangelnPQW = zeros(3,1440);
BDS_velocitylnPQW = zeros(3,1440);
%24hour in min
for t=1:1:1441
    %PQW range & velocity
    BDS_rangelnPQW(:,t) = solveRangelnPerifocalFrame(BDS_a, BDS_e, nu(t)*180/pi);
    BDS_velocitylnPQW(:,t) = solveVelocitylnPerifocalFrame(BDS_a, BDS_e, nu(t)*180/pi);
end

    %PQW -> ECI
    BDS_ECI = PQW2ECI(BDS_arg, BDS_i, BDS_RAAN);
    BDS_rangelnECI=BDS_ECI*BDS_rangelnPQW;
    BDS_velocitylnECI=BDS_ECI*BDS_velocitylnPQW;
    
    %ECI -> ECEF
    BDS_rangelnECEF = zeros(3,1440);
    BDS_velocitylnECEF = zeros(3,1440);
    for t=1:1:1441
        DCM=ECI2ECEF_DCM(BDS_t(t,:)); 
        BDS_rangelnECEF(:,t)=DCM*BDS_rangelnECI(:,t); 
        BDS_velocitylnECEF(:,t)=DCM*BDS_velocitylnECI(:,t);
    end
    
    %ECEF-> geodetic
    wgs84 = wgs84Ellipsoid('kilometer');
    for t=1:1:1441
        [lat(t), lon(t), h(t)]= ecef2geodetic(wgs84, BDS_rangelnECEF(1,t),BDS_rangelnECEF(2,t),BDS_rangelnECEF(3,t));

    end
% ground track
figure(1)
geoplot(lat, lon,'y.')
geolimits([-90 90],[-180 180]) 
legend('BDS')

figure(2);
plot3(BDS_rangelnECI(1,:),BDS_rangelnECI(2,:),BDS_rangelnECI(3,:))