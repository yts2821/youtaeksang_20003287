close
clear
clc
load nav.mat
QZSS_a = (nav.QZSS.a) / 10^3;                                              
QZSS_e = nav.QZSS.e;                                                  
QZSS_p = QZSS_a * (1- QZSS_e^2);                                       
QZSS_i = nav.QZSS.i*180/pi;                                         
QZSS_arg = nav.QZSS.omega*180/pi;                                    
QZSS_RAAN = nav.QZSS.OMEGA*180/pi;         
QZSS_M0 = nav.QZSS.M0;                                                       
QZSS_t = zeros(1440,6);
for i=0:1:1440
    nu(i+1) = true_anomaly(QZSS_a, QZSS_e, [0 0 0 0 i 0], nav.QZSS.toc, QZSS_M0);       %[rad]
    QZSS_t(i+1,:) = nav.QZSS.toc+[0 0 0 0 i 0];
end
QZSS_ENU=[0 0 0];
%ground station
lat=37;             
lon=127;            
h=1;                
el_mask=10;         

QZSS_rangelnPQW = zeros(3,1440);
QZSS_velocitylnPQW = zeros(3,1440);
%24hour in min
for t=1:1:1441
    %PQW range & velocity
    QZSS_rangelnPQW(:,t) = solveRangelnPerifocalFrame(QZSS_a, QZSS_e, nu(t)*180/pi);
    QZSS_velocitylnPQW(:,t) = solveVelocitylnPerifocalFrame(QZSS_a, QZSS_e, nu(t)*180/pi);
end

    %PQW -> ECI
    QZSS_ECI = PQW2ECI(QZSS_arg, QZSS_i, QZSS_RAAN);
    QZSS_rangelnECI=QZSS_ECI*QZSS_rangelnPQW;
    QZSS_velocitylnECI=QZSS_ECI*QZSS_velocitylnPQW;
    
    %ECI -> ECEF
    QZSS_rangelnECEF = zeros(3,1440);
    QZSS_velocitylnECEF = zeros(3,1440);
    for t=1:1:1441
        DCM=ECI2ECEF_DCM(QZSS_t(t,:)); 
        QZSS_rangelnECEF(:,t)=DCM*QZSS_rangelnECI(:,t); 
        QZSS_velocitylnECEF(:,t)=DCM*QZSS_velocitylnECI(:,t);
    end
    
    %ECEF-> geodetic
    wgs84 = wgs84Ellipsoid('kilometer');
    for t=1:1:1441
        [lat(t), lon(t), h(t)]= ecef2geodetic(wgs84, QZSS_rangelnECEF(1,t),QZSS_rangelnECEF(2,t),QZSS_rangelnECEF(3,t));

    end
% ground track
figure(1)
geoplot(lat, lon,'y.')
geolimits([-90 90],[-180 180]) 
legend('QZSS')

figure(2);
plot3(QZSS_rangelnECI(1,:),QZSS_rangelnECI(2,:),QZSS_rangelnECI(3,:))